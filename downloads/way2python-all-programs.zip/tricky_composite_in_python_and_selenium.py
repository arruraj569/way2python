print(all([]))
print(any([]))
