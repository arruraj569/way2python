WAY2PYTHON DESIGN PATTERNS
96 standalone programs: 32 Python rehearsals, 32 tricky exercises and
32 real Selenium companions. No third-party package is needed for rehearsals
or tricky exercises. Run them with python filename.py. Driver doubles are
labelled; they do not open a browser.

For selenium_ files: install selenium in an activated environment, install
Chrome, and keep http://localhost:8080/way2python/practice.html running.
Run python selenium_filename.py (use the actual downloaded filename).
Selenium Manager may need network access to obtain a matching driver.
The Abstract Factory companion optionally supports installed Firefox.

The framework folder contains a modular pytest suite. Read its README.txt
for exact setup, expected results, optional settings and verification scope.
Read the full lessons at http://localhost:8080/way2python/design-patterns.html.
